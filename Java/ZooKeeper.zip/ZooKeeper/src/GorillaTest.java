

public class GorillaTest {

	public static void main(String[] args) {
		Gorilla felix = new Gorilla();
		
		felix.displayEnergy();
		felix.throwSomething();
		felix.throwSomething();
		felix.throwSomething();
		felix.eatBananas();
		felix.eatBananas();
		felix.climb();
		felix.displayEnergy();

	}

}

productlist= [
    {
        'productid':1, 
        'name': 'bees', 
        'price':5.00 
    },
    {
        'productid':2, 
        'name': "pickles", 
        'price': 10.00 
    },
    {
        'productid':3, 
        'name': 'fire', 
        'price':20.00 
    },
    {
        'productid':4, 
        'name': 'bats', 
        "price":50.00 
    },
    {
        'productid':5, 
        'name': 'dignity', 
        'price':100.00 
    }
]

package com.valociraptor.countries.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.valociraptor.countries.services.ApiService;



@Controller
public class Countries {
	private final ApiService apiService;
	
	public Countries(ApiService apiService) {
		this.apiService = apiService;
	}

	@RequestMapping("/")
	public String index() {
		List<Object[]> countries = apiService.findCountriesWithNumCities();
		for(Object[] row : countries) {
			System.out.println(row[0]);
			System.out.println(row[1]);
		}
		return "index.jsp";
	}
}

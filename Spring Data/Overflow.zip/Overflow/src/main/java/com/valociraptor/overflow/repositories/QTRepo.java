/*package com.valociraptor.overflow.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.valociraptor.overflow.models.QuestionTag;

@Repository
public interface QTRepo extends CrudRepository<QuestionTag, Long> {

}
*/
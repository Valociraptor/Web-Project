package models;

public abstract class Animal {
	protected String name;
	protected String breed;
	protected double weight;

}

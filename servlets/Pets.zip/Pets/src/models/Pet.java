package models;

public interface Pet {
	String showAffection();
}

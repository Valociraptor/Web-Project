package com.codingdojo.web.models;

import java.util.ArrayList;

public class Roster {
	public static ArrayList<Team> allTeams = new ArrayList<Team>();
}